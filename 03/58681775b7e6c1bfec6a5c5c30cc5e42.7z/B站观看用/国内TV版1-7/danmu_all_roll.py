import os
import re
for file in os.listdir():
    try:
        if not file.endswith(".xml"):
            continue
        with open(file, "r", encoding="utf-8") as f:
            xml = f.read()
        xml_head = re.findall(r'^(.*?)<d p="', xml, re.DOTALL | re.IGNORECASE)
        if len(xml_head) != 1:
            raise Exception("识别xml头错误")
        xml_head = xml_head[0]
        danmus = re.findall(
            r'<d p="(.*?),(.*?),(.*?),(.*?),(.*?),(.*?),(.*?),(.*?)">(.*?)</d>', xml, re.DOTALL | re.IGNORECASE)
        danmus_temp = [list(danmu) for danmu in danmus]
        for danmu in danmus_temp:
            danmu[1] = "1"
        danmu_content = []
        for danmu in danmus_temp:
            danmu_content.append(
                '<d p="{},{},{},{},{},{},{},{}">{}</d>'.format(*danmu))
        xml_new = xml_head + "".join(danmu_content) + "</i>"
        with open(f'【全滚动弹幕】{file}', "w", encoding="utf-8") as f:
            f.write(xml_new)
    except:
        print(f'{file}文件转换失败 ❌')
    else:
        print(f'{file}文件转换完成 ✔')
input()